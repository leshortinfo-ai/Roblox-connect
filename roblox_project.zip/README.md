# Roblox Player Finder - Projet prêt à déployer

## Structure
- `backend/` : FastAPI backend (main.py)
- `frontend/` : page statique (index.html, style.css, script.js)
- `requirements.txt` : dépendances Python
- `Procfile` : utilisé par Render / Heroku

## Tester localement
1. Installer Python 3.10+.
2. Créer un virtualenv :
   ```
   python -m venv .venv
   source .venv/bin/activate   # mac/linux
   .venv\Scripts\activate    # windows
   ```
3. Installer dépendances :
   ```
   pip install -r requirements.txt
   ```
4. Lancer le backend :
   ```
   uvicorn backend.main:app --reload
   ```
   -> backend écoute sur http://localhost:8000
5. Ouvrir `frontend/index.html` dans le navigateur (ou servir le dossier frontend via `npx serve` ou `python -m http.server 3000`).
6. Tester en entrant un pseudo Roblox.

## Déploiement rapide (suggestion)
- Backend : Render / Railway / Heroku (pousser repo GitHub).
- Frontend : Netlify / Vercel (drag & drop du dossier `frontend` ou lier le repo).
- Après déploiement, modifier `frontend/script.js` pour pointer vers l'URL publique du backend.

## Notes importantes
- Ce backend appelle l'API publique de Roblox. Respecte les limites et ajoute du cache (Redis) pour éviter d'être bloqué.
- Pour retrouver le serveur exact du joueur (placeId/serverId) tu dois connecter ton microservice `game-finder` ou utiliser des méthodes supplémentaires (puis-je intégrer ton microservice ?).