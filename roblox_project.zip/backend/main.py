from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import httpx
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ROBLOX_API_USER = "https://api.roblox.com/users/get-by-username?username="
ROBLOX_AVATAR = "https://www.roblox.com/headshot-thumbnail/image"

@app.get("/api/player/{username}")
async def get_player(username: str):
    async with httpx.AsyncClient() as client:
        res = await client.get(ROBLOX_API_USER + username)
        if res.status_code != 200:
            raise HTTPException(status_code=502, detail="Erreur API Roblox")
        data = res.json()

        if "Id" not in data:
            raise HTTPException(status_code=404, detail="Joueur introuvable")

        user_id = data["Id"]
        avatar_url = f"{ROBLOX_AVATAR}?userId={user_id}&width=150&height=150&format=png"

        server_info = {
            "status": "Hors ligne",
            "placeId": None,
            "serverId": None,
            "joinUrl": None
        }

        return {
            "userId": user_id,
            "username": username,
            "avatar": avatar_url,
            "server": server_info
        }